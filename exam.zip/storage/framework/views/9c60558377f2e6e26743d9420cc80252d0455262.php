<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Permohonan Menduduki Exam</div>
                <div class="panel-body">

                  <?php echo $__env->make('layouts/alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  <form class="form-horizontal" method="POST" action="<?php echo e(route('storepermohonan')); ?>">
                      <?php echo e(csrf_field()); ?>


                      <div class="form-group">
                          <label for="exam_id" class="col-md-4 control-label">Pilihan Exam</label>

                          <div class="col-md-6">
                              <select name="exam_id" class="form-control">
                                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?> (<?php echo e($item->tarikh_mula); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>

                      <div class="form-group">
                          <div class="col-md-8 col-md-offset-4">
                              <button type="submit" class="btn btn-primary">
                                  Hantar Permohonan
                              </button>
                          </div>
                      </div>
                  </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>