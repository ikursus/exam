<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Senarai Permohonan Exam</div>

                <div class="panel-body">

                    <p>
                      <a href="<?php echo e(route('paparborangpermohonan')); ?>" class="btn btn-primary">Pohon Exam Baru</a>
                    </p>

                    <?php echo $__env->make('layouts/alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php if( count( $senarai_permohonan ) ): ?>

                    <p>Berikut adalah senarai permohonan exam yang telah dibuat.</p>

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>NAMA PEMOHON</th>
                          <th>NAMA EXAM</th>
                          <th>STATUS</th>
                          <th>ACTION</th>
                        </tr>
                      </thead>
                    <tbody>
                    <?php $__currentLoopData = $senarai_permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td>
                          <?php if( count($item->rekoduser ) ): ?>
                          <?php echo e($item->rekoduser->nama); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                          <?php echo e($item->rekodexam->nama); ?>

                        </td>
                        <td><?php echo e(ucwords( $item->status )); ?></td>
                        <td>

                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modal-delete-<?php echo e($item->id); ?>">
                            DELETE
                          </button>

                          <!-- Modal -->
                          <form method="POST" action="<?php echo e(route('deletepermohonan', $item->id)); ?>">
                          <div class="modal fade" id="modal-delete-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                  <h4 class="modal-title" id="myModalLabel">PENGESAHAN HAPUS DATA</h4>
                                </div>
                                <div class="modal-body">

                                  Adakah anda ingin menghapuskan data : <?php echo e($item->nama); ?>?

                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete">


                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                  <button type="submit" class="btn btn-danger">SAHKAN</button>
                                </div>
                              </div>
                            </div>
                          </div>
                          </form>



                        </td>
                      </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>

                    <?php else: ?>
                    <div class="alert alert-info">Tiada rekod senarai permohonan exam buat masa ini</div>
                    <?php endif; ?>

                    <?php echo $senarai_permohonan->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>