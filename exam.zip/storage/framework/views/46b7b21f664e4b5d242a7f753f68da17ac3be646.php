<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Senarai Users</div>

                <div class="panel-body">
                    Berikut adalah maklumat bagi user <?php echo e($user->nama); ?>.

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>NAMA</th>
                          <th>EMAIL</th>
                        </tr>
                      </thead>
                    <tbody>
                      <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->nama); ?></td>
                        <td><?php echo e($user->email); ?></td>
                      </tr>
                    </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>


    <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Senarai Permohonan Exam oleh <?php echo e($user->nama); ?></div>

                <div class="panel-body">
                    Berikut adalah maklumat senarai permohonan bagi user <?php echo e($user->nama); ?>.

                    <?php if( count( $user->senaraiPermohonan ) ): ?>

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>NAMA EXAM</th>
                        </tr>
                      </thead>
                    <tbody>
                      <?php $__currentLoopData = $user->senaraiPermohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($permohonan->status); ?></td>
                        <td><?php echo e($permohonan->rekodexam->nama); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>

                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>